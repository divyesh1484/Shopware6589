<?php declare(strict_types=1);

namespace IctBlogPlugin\Core\Content\IctBlog\Aggregate;

use IctBlogPlugin\Core\Content\IctBlog\IctBlogDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityTranslationDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\StringField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;

class IctBlogTranslationDefinition extends EntityTranslationDefinition
{
    const ENTITY_NAME = 'ict_blog_translation';

    public function getEntityName(): string
    {
        return self::ENTITY_NAME;
    }
    public function getParentDefinitionClass(): string
    {
        return IctBlogDefinition::class;
    }
    public function getCollectionClass(): string
    {
        return IctBlogTranslationCollection::class;
    }
    public function getEntityClass(): string
    {
        return IctBlogTranslationEntity::class;
    }
    protected function defineFields(): FieldCollection
    {
        return new FieldCollection(
            [
                new StringField('name', 'name'),
                new StringField('description', 'description'),
                new StringField('author', 'author'),
            ]
        );
    }
}

