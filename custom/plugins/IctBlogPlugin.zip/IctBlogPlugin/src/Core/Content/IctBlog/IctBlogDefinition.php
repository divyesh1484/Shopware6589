<?php declare(strict_types=1);

namespace IctBlogPlugin\Core\Content\IctBlog;

use IctBlogPlugin\Core\Content\IctBlog\Aggregate\IctBlogTranslationDefinition;
use IctBlogPlugin\Core\Content\IctBlogProductMappingDefinition;
use IctBlogPlugin\Core\Content\IctCategory\IctCategoryDefinition;
use Shopware\Core\Content\Product\ProductDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\BoolField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\DateField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\FkField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\CascadeDelete;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\PrimaryKey;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\Required;
use Shopware\Core\Framework\DataAbstractionLayer\Field\IdField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\ManyToManyAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\OneToOneAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\TranslatedField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\TranslationsAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;

class IctBlogDefinition extends EntityDefinition
{
    const ENTITY_NAME = 'ict_blog';

    public function getEntityName(): string
    {
        return self::ENTITY_NAME;
    }

    public function getCollectionClass(): string
    {
        return IctBlogCollection::class;
    }

    public function getEntityClass(): string
    {
        return IctBlogEntity::class;
    }

    protected function defineFields(): FieldCollection
    {
        return new FieldCollection(
            [
                (new IdField('id', 'id'))->addFlags(new Required(), new PrimaryKey()),
                new TranslatedField('name'),
                new TranslatedField('description'),
                new TranslatedField('author'),
                new DateField('release_date', 'releaseDate'),
                new BoolField('active', 'active'),
                (new FkField('ict_category_id', 'ictCategoryId', IctCategoryDefinition::class))->addFlags(new Required()),
                (new OneToOneAssociationField('ictCategory', 'ict_category_id', 'id', IctCategoryDefinition::class,false)),

                new ManyToManyAssociationField(
                    'products',
                    ProductDefinition::class,
                    IctBlogProductMappingDefinition::class,
                    'ict_blog_id',
                    'product_id'),

                (new TranslationsAssociationField(
                    IctBlogTranslationDefinition::class,
                    'ict_blog_translation_id')
                )->addFlags(new Required()),
            ]
        );
    }
}






















