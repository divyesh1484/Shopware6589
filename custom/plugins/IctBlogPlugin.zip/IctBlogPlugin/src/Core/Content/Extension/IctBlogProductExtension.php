<?php declare(strict_types=1);

namespace DemoBlogBookBasicInfo\Core\Content\Extension;

use DemoBlogBookBasicInfo\Core\Content\DemoBlog\DemoDefinition;
use DemoBlogBookBasicInfo\Core\Content\DemoCategory\DemoCategoryDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityExtension;
use Shopware\Core\Framework\DataAbstractionLayer\Field\ManyToOneAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;

class IctBlogProductExtension extends EntityExtension
{
    public function extendFields(FieldCollection $collection): void
    {
        $collection->add(
            new ManyToOneAssociationField(
                'demoBlog1Id',
                'demo_blog1_Id',
                DemoDefinition::class,
                'id'),
        );
    }
    public function getDefinitionClass(): string
    {
        return DemoCategoryDefinition::class;
    }
}



