<?php declare(strict_types=1);

namespace IctBlogPlugin\Core\Content\Extension;

use IctBlogPlugin\Core\Content\IctBlog\IctBlogDefinition;
use IctBlogPlugin\Core\Content\IctBlogProductMappingDefinition;
use Shopware\Core\Content\Product\ProductDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityExtension;
use Shopware\Core\Framework\DataAbstractionLayer\Field\ManyToManyAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;

class ProductExtension extends EntityExtension
{
    public function extendFields(FieldCollection $collection): void
    {
        $collection->add(
                new ManyToManyAssociationField(
                    'products',
                    IctBlogDefinition::class,
                    IctBlogProductMappingDefinition::class,
                    'product_id',
                    'ict_blog_id'),
        );
    }
    public function getDefinitionClass(): string
    {
        return ProductDefinition::class;
    }
}



