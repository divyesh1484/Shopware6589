<?php declare(strict_types=1);

namespace IctBlogPlugin\Core\Content\Extension;

use IctBlogPlugin\Core\Content\IctBlog\IctBlogDefinition;
use IctBlogPlugin\Core\Content\IctCategory\IctCategoryDefinition;
use Shopware\Core\Content\Category\CategoryDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityExtension;
use Shopware\Core\Framework\DataAbstractionLayer\Field\OneToOneAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\CascadeDelete;

class IctCategoryExtension extends EntityExtension
{
    /**
     * @param FieldCollection $collection
     * @return void
     */
    public function extendFields(FieldCollection $collection): void
    {
        $collection->add(
            (new OneToOneAssociationField('category', 'id', 'ict_category_id', IctBlogDefinition::class, true))->addFlags(new CascadeDelete())
        );
    }

    public function getDefinitionClass(): string
    {
        return IctCategoryDefinition::class;
    }
}
